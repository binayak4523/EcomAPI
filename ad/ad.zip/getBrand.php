<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include 'db.php';
// Create connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM brands";
$result = $conn->query($sql);
$brands = array();

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $brands[] = $row;
    }
}
echo json_encode($brands);
$conn->close();
?>
