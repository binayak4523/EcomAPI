<?php
// api/pg/handleJuspayReturn.php

// Allow cross-origin if needed
header("Access-Control-Allow-Origin: *");

// Read POST data
$order_id = $_POST['order_id'] ?? '';
$status = $_POST['status'] ?? '';
$status_id = $_POST['status_id'] ?? '';
$signature = $_POST['signature'] ?? '';

// Optional: Verify the signature here using Juspay SDK (recommended for security)

// Redirect to frontend with query params
$redirect_url = "http://localhost:3000/payment-status?" .
    http_build_query([
        'order_id' => $order_id,
        'status' => $status,
        'status_id' => $status_id,
        'signature' => $signature
    ]);

header("Location: $redirect_url");
exit();
?>